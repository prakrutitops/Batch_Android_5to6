package com.example.task8


class Model
{
    var name=""
    var categoryname=""
    var imagejsonurl=""
}